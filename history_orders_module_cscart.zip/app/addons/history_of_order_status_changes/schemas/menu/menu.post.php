<?php

$schema['central']['orders']['items']['history_of_order_status_changes'] = array(
    'position' => 150,
    'href' => 'history_of_order_status_changes.manage'
);

return $schema;