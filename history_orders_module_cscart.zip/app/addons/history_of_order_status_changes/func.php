<?php

if (!defined('BOOTSTRAP')) { die('Access denied'); }

function fn_history_of_order_status_changes_change_order_status_before_update_product_amount($order_id, $status_to, $status_from, $force_notification, $place_order, $order_info, $k, $v) {
    $old_status = db_get_field("SELECT status FROM ?:orders WHERE order_id = ?i", $order_id);
    db_query("UPDATE ?:orders SET old_status = ?s, user_change_id = ?i, date_changes = ?i WHERE order_id = ?i", $old_status, Tygh::$app['session']['auth']['user_id'], TIME, $order_id);
}

function fn_history_of_order_status_changes_pre_get_orders($params, &$fields, &$sortings, $get_totals, $lang_code) {
	array_push($fields, "?:orders.old_status", "?:orders.user_change_id", "?:orders.date_changes");

	$sortings['old_status']  = "?:orders.old_status";
	$sortings['user_change_id'] = "?:orders.user_change_id";
	$sortings['date_changes'] = "?:orders.date_changes";
}

function fn_history_of_order_status_changes_get_orders(&$params, $fields, $sortings, &$condition, $join, $group) {
	if (isset($params['user_change_id'])) {
        $condition .= db_quote(' AND ?:orders.user_change_id > ?i', $params['user_change_id']);
    }
}