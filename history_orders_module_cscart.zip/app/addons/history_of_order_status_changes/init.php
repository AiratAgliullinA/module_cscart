<?php

if (!defined('BOOTSTRAP')) { die('Access denied'); }

fn_register_hooks(
    'change_order_status_before_update_product_amount',
    'pre_get_orders',
    'get_orders'
);