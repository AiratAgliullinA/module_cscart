<?php

if (!defined('BOOTSTRAP')) { die('Access denied'); }

define('DEFAULT_USER_CHANGE_ID', 0);