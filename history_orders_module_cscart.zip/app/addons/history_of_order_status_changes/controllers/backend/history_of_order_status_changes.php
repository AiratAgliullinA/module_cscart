<?php

use Tygh\Registry;

if (!defined('BOOTSTRAP')) { die('Access denied'); }

$params = $_REQUEST;

if ($mode == 'manage') {

    $params['user_change_id'] = DEFAULT_USER_CHANGE_ID;

    list($orders, $search) = fn_get_orders($params, Registry::get('settings.Appearance.admin_elements_per_page'));
    foreach ($orders as $key => $val) {
		$user_info = fn_get_user_info($val['user_change_id']);
		$orders[$key]['user_name'] = $user_info['firstname'];

		$order_status_description = fn_get_simple_statuses(STATUSES_ORDER, true, true);
		$orders[$key]['status'] = $order_status_description[$val['status']];
		$orders[$key]['old_status'] = $order_status_description[$val['old_status']];
    }
    
    Tygh::$app['view']->assign('orders', $orders);
    Tygh::$app['view']->assign('search', $search);
}